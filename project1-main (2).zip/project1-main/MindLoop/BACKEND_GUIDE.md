# 🧠 MindLoop - Full Stack Prototype

A **lightweight, feature-complete hackathon prototype** for a student learning platform with React frontend and Node.js backend.

## 📋 What's Included

### ✅ Frontend (React + Vite)
- Login/Registration screen
- Student dashboard
- PDF upload interface
- Summary display
- Interactive quiz with scoring
- Flip-to-reveal flashcards
- Responsive design (Blue/Purple theme)
- Full API integration

### ✅ Backend (Node.js + Express)
- JWT authentication
- User management
- File upload handling
- Quiz management & auto-scoring
- Flashcard system
- Summary generation
- CORS enabled for frontend
- In-memory database (easy to swap)

---

## 🚀 Quick Start (2 Steps)

### Step 1: Install Dependencies
```bash
# Backend
cd MindLoop/backend
npm install

# Frontend (in another terminal)
cd MindLoop
npm install
```

### Step 2: Start Services

**Option A: Run Individually**
```bash
# Terminal 1 - Backend (Port 3001)
cd MindLoop/backend
npm start

# Terminal 2 - Frontend (Port 5173)
cd MindLoop
npm run dev
```

**Option B: Run Both (Windows)**
```bash
# Double-click
MindLoop/start.bat
```

**Option C: Run Both (Mac/Linux)**
```bash
bash MindLoop/start.sh
```

---

## 📱 Access the App

| Service | URL | Status |
|---------|-----|--------|
| Frontend | http://localhost:5173 | Open in browser |
| Backend API | http://localhost:3001 | No UI, API only |
| Health Check | http://localhost:3001/api/health | { "status": "Backend is running!" } |

---

## 🔐 How the App Works

### Login Flow
```
1. User enters: Name, Class, Course
2. Frontend sends POST to /api/auth/login
3. Backend generates JWT token
4. Frontend stores token in localStorage
5. All API calls include: Authorization: Bearer <token>
6. User logged in → Redirect to /home
```

### Quiz Flow
```
1. Click "Quiz" button on home
2. Frontend fetches 5 questions from /api/quiz/questions
3. User selects answers
4. Submit → POST answers to /api/quiz/submit
5. Backend calculates score
6. Display results with feedback
```

### Flashcard Flow
```
1. Click "Flashcards" button
2. Frontend fetches all cards from /api/flashcards
3. User navigates cards and clicks to flip
4. Click number buttons to jump to specific card
5. All interaction happens client-side
```

---

## 📚 Backend Architecture

```
backend/
├── server.js              # Express app setup, routes registration
├── package.json           # Dependencies
├── .env                   # Environment config
│
├── middleware/
│   └── auth.js           # JWT token generation & verification
│
├── database/
│   └── init.js           # In-memory data storage
│
└── routes/
    ├── auth.js           # Login, Register, Get User
    ├── notes.js          # Upload, List, Delete files
    ├── summary.js        # Summary & key points
    ├── quiz.js           # Questions, Submit, History
    └── flashcards.js     # Cards, Sets, Progress
```

### Key Files Explained

**`server.js`** - Main Express server
- Sets up middleware (CORS, JSON parsing)
- Registers all API routes
- Listens on port 3001

**`middleware/auth.js`** - Authentication
- `generateToken()` - Creates JWT from userId
- `verifyToken()` - Validates JWT
- `authMiddleware` - Protects routes (checks Authorization header)

**`database/init.js`** - In-Memory Storage
- `users[]` - Stores user data
- `notes[]` - Stores uploaded files
- `quizSubmissions[]` - Stores quiz scores
- Resets on server restart (perfect for demo)

**`routes/auth.js`** - Authentication Routes
- `POST /api/auth/login` - Returns token + user data
- `POST /api/auth/register` - Creates new user, returns token
- `GET /api/auth/me` - Returns logged-in user

**`routes/quiz.js`** - Quiz Routes
- `GET /api/quiz/questions` - Returns 5 MCQs
- `POST /api/quiz/submit` - Grades answers, returns score
- `GET /api/quiz/history` - Returns past quiz attempts

---

## 🎨 Frontend API Integration

### Setup (`src/api.js`)
```javascript
import { login, getQuizQuestions, submitQuiz } from './api'

// Login
const response = await login('John', '5th', 'Mathematics')
// Returns: { success: true, token: "...", user: {...} }

// Quiz
const questions = await getQuizQuestions()
// Returns list of 5 questions

const result = await submitQuiz({ 1: 0, 2: 1, 3: 2, 4: 3, 5: 1 })
// Returns: { score: 4, totalQuestions: 5, percentage: 80, feedback: "..." }
```

### How Components Use API

**Login.jsx**
```javascript
const response = await login(name, studentClass, course)
if (response.success) {
  setStudentInfo(response.user)
  navigate('/home')
}
```

**Quiz.jsx**
```javascript
// Load questions on mount
const response = await getQuizQuestions()
setQuestions(response.questions)

// Submit answers
const result = await submitQuiz(answers)
setResult(result)
```

**Flashcards.jsx**
```javascript
// Load flashcards
const response = await getFlashcards()
setFlashcards(response.flashcards)
```

---

## 🔌 API Endpoints Reference

### Authentication
```
POST   /api/auth/login
       body: { name, studentClass, course }
       returns: { success, token, user }

POST   /api/auth/register
       body: { name, studentClass, course, email?, password? }
       returns: { success, token, user }

GET    /api/auth/me
       headers: { Authorization: Bearer <token> }
       returns: { id, name, studentClass, course }
```

### Notes
```
POST   /api/notes/upload
       headers: { Authorization: Bearer <token> }
       body: FormData { file, course }
       returns: { success, file }

GET    /api/notes
       headers: { Authorization: Bearer <token> }
       returns: { success, notes[] }

DELETE /api/notes/:id
       headers: { Authorization: Bearer <token> }
       returns: { success }
```

### Quiz
```
GET    /api/quiz/questions
       headers: { Authorization: Bearer <token> }
       returns: { success, questions[] }

POST   /api/quiz/submit
       headers: { Authorization: Bearer <token> }
       body: { answers: { questionId: answerIndex } }
       returns: { score, totalQuestions, percentage, feedback }

GET    /api/quiz/history
       headers: { Authorization: Bearer <token> }
       returns: { success, history[] }
```

### Summary
```
GET    /api/summary/:noteId
       headers: { Authorization: Bearer <token> }
       returns: { noteId, summary }

GET    /api/summary
       headers: { Authorization: Bearer <token> }
       returns: { summaries[] }
```

### Flashcards
```
GET    /api/flashcards
       headers: { Authorization: Bearer <token> }
       returns: { success, flashcards[] }

GET    /api/flashcards/set/:setId
       headers: { Authorization: Bearer <token> }
       returns: { success, set }

POST   /api/flashcards/:cardId/learn
       headers: { Authorization: Bearer <token> }
       returns: { success }

GET    /api/flashcards/progress/all
       headers: { Authorization: Bearer <token> }
       returns: { totalCards, learned, inProgress, percentage }
```

---

## 🛠️ Environment Setup

### `.env` File
```
PORT=3001
JWT_SECRET=mindloop-secret-key-2024
FRONTEND_URL=http://localhost:5173
NODE_ENV=development
```

### Frontend API URL
Edit `src/api.js`:
```javascript
const API_BASE_URL = 'http://localhost:3001/api'
```

---

## 💡 Key Features

✅ **No Database Needed** - In-memory storage works perfectly for demos
✅ **JWT Authentication** - Secure token-based login
✅ **File Upload Ready** - Multer configured for PDFs
✅ **CORS Enabled** - Frontend can call backend freely
✅ **Error Handling** - Try-catch on all routes
✅ **Clean Code** - Well-structured, easy to extend
✅ **Modular Routes** - Each feature in separate file
✅ **Auto-Scoring** - Quiz instantly grades answers

---

## 🚀 Extending the Backend

### Add a New Route

1. Create `backend/routes/myfeature.js`:
```javascript
import express from 'express'
import { authMiddleware } from '../middleware/auth.js'

const router = express.Router()

router.get('/data', authMiddleware, (req, res) => {
  res.json({ success: true, data: [...] })
})

export default router
```

2. Register in `server.js`:
```javascript
import myFeatureRoutes from './routes/myfeature.js'
app.use('/api/myfeature', myFeatureRoutes)
```

3. Use in frontend:
```javascript
const response = await fetch('http://localhost:3001/api/myfeature/data', {
  headers: { Authorization: `Bearer ${token}` }
})
```

---

## 📊 Quiz Scoring Logic

```javascript
// Hardcoded correct answers
const correctAnswers = { 1: 1, 2: 1, 3: 2, 4: 1, 5: 1 }

// User answers
const answers = { 1: 1, 2: 0, 3: 2, 4: 1, 5: 1 }

// Scoring
score = 0
for (questionId in answers) {
  if (answers[questionId] === correctAnswers[questionId]) {
    score++
  }
}

percentage = (score / 5) * 100
```

---

## 🐛 Debugging Tips

### Check if backend is running
```bash
curl http://localhost:3001/api/health
# Should return: { "status": "Backend is running!" }
```

### View API requests
1. Open browser DevTools (F12)
2. Go to Network tab
3. Make a login attempt
4. Click on the POST request
5. Check Request/Response tabs

### Check tokens in localStorage
```javascript
// In browser console:
console.log(localStorage.getItem('mindloop_token'))
```

### View server logs
Look at the terminal running `npm start` for console.log outputs

---

## 🎓 Learning Resources

### Understanding the Flow
1. User clicks Login
2. `Login.jsx` calls `api.login()`
3. `api.js` sends POST request
4. Express receives at `auth.js`
5. Generates JWT token
6. Response sent back to frontend
7. Token stored in localStorage
8. Used for future API calls

### Testing the API Manually
```bash
# Login
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"name":"John","studentClass":"5th","course":"Math"}'

# Response contains token, store it:
TOKEN="eyJ..."

# Get Quiz Questions
curl -X GET http://localhost:3001/api/quiz/questions \
  -H "Authorization: Bearer $TOKEN"
```

---

## 📦 Deployment Checklist

Before deploying to production:

- [ ] Replace in-memory database with MongoDB/PostgreSQL
- [ ] Add password hashing (bcrypt)
- [ ] Move JWT secret to environment variable
- [ ] Add rate limiting
- [ ] Add input validation (joi/express-validator)
- [ ] Add logging (winston/morgan)
- [ ] Add tests (jest/supertest)
- [ ] Configure HTTPS
- [ ] Add request timeout
- [ ] Set up CI/CD pipeline

---

## 🎉 You're All Set!

Your MindLoop backend is ready to serve requests. The frontend is already configured to use it.

**Next Steps:**
1. Open http://localhost:5173
2. Login with any name/class/course
3. Explore all features
4. Check browser DevTools Network tab to see API calls
5. Try modifying data in the backend routes!

---

**Happy Hacking! 🚀**