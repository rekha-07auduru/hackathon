# MindLoop - Full Stack Hackathon Prototype
## Complete Setup & Deployment Guide

---

## 🚀 Quick Start (Run Both Frontend & Backend)

### Terminal 1 - Start Backend (Port 3001)
```bash
cd MindLoop/backend
npm install
npm start
```
**Output should show:** `🚀 Server running on http://localhost:3001`

### Terminal 2 - Start Frontend (Port 5173)
```bash
cd MindLoop
npm install
npm run dev
```
**Output should show:** `Local: http://localhost:5173/`

---

## 📁 Project Structure

```
MindLoop/
├── backend/                    # Node.js + Express
│   ├── server.js              # Main server file
│   ├── package.json           # Backend dependencies
│   ├── .env                   # Environment variables
│   ├── middleware/
│   │   └── auth.js            # JWT authentication
│   ├── database/
│   │   └── init.js            # In-memory database
│   └── routes/
│       ├── auth.js            # Login/Register
│       ├── notes.js           # File uploads
│       ├── summary.js         # Summary data
│       ├── quiz.js            # Quiz management
│       └── flashcards.js      # Flashcards
│
├── src/                       # React Frontend
│   ├── main.jsx              # Entry point
│   ├── App.jsx               # Router setup
│   ├── api.js                # API calls
│   ├── index.css             # Styling
│   └── pages/
│       ├── Login.jsx         # Authentication
│       ├── Home.jsx          # Dashboard
│       ├── UploadNotes.jsx   # File upload
│       ├── Summary.jsx       # Summary display
│       ├── Quiz.jsx          # Quiz screen
│       └── Flashcards.jsx    # Flashcard viewer
├── package.json              # Frontend dependencies
├── vite.config.js            # Vite configuration
└── index.html                # HTML template
```

---

## 🔌 API Endpoints

### Authentication
```
POST /api/auth/login           - Login user
POST /api/auth/register        - Register new student
GET  /api/auth/me              - Get current user
```

### Notes
```
POST /api/notes/upload         - Upload PDF
GET  /api/notes                - Get user's notes
DELETE /api/notes/:id          - Delete note
```

### Summary
```
GET /api/summary/:noteId       - Get summary
GET /api/summary               - Get all summaries
```

### Quiz
```
GET  /api/quiz/questions       - Get quiz questions
POST /api/quiz/submit          - Submit answers
GET  /api/quiz/history         - Get quiz history
```

### Flashcards
```
GET /api/flashcards            - Get all cards
GET /api/flashcards/set/:id    - Get specific set
POST /api/flashcards/:id/learn - Mark as learned
GET /api/flashcards/progress   - Get progress
```

---

## 🔐 How Authentication Works

1. **Login**: User enters name, class, course
2. **Backend**: Generates JWT token
3. **Frontend**: Stores token in localStorage
4. **API Calls**: Include token in Authorization header
   ```
   Authorization: Bearer <token>
   ```

---

## 💾 Database (In-Memory)

For hackathon simplicity, data is stored in **RAM**:
- Resets when server restarts
- No persistence
- Perfect for prototyping

**To add database:**
- Replace `backend/database/init.js` with MongoDB/Firebase config
- Update routes to use database calls instead of in-memory arrays

---

## 📝 API Usage Examples

### Login
```javascript
fetch('http://localhost:3001/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'John Doe',
    studentClass: '5th',
    course: 'Mathematics'
  })
})
```

### Quiz Submit
```javascript
fetch('http://localhost:3001/api/quiz/submit', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer <token>'
  },
  body: JSON.stringify({
    answers: { 1: 0, 2: 1, 3: 2 }
  })
})
```

---

## 🎨 Frontend Features

✅ **Login Screen**
- Student name input
- Class dropdown (6-12th grade)
- Course selection (Math, English, Science, etc.)
- Error handling

✅ **Home Dashboard**
- Welcome message with student name
- 4 activity buttons (Upload, Summary, Quiz, Flashcards)
- Logout option

✅ **Upload Notes**
- PDF file input
- Visual upload feedback
- File name display

✅ **Summary**
- Dummy summary text
- 4 important points
- Link to quiz

✅ **Quiz**
- 5 hardcoded questions
- Radio button selection
- Auto-scoring
- Detailed results page

✅ **Flashcards**
- 6 flip-to-reveal cards
- Navigation buttons
- Card indicator dots
- Progress tracking

---

## 🐛 Troubleshooting

### Backend won't start
```bash
# Check if port 3001 is in use
netstat -ano | findstr :3001

# Kill process if needed
taskkill /PID <PID> /F
```

### Frontend can't connect to backend
- Make sure backend is running on port 3001
- Check CORS in `server.js` allows localhost:5173
- Browser console will show connection error

### "Missing imports" error
```bash
# Reinstall dependencies
npm install

# Clear node_modules
rm -r node_modules
npm install
```

---

## 📦 Deployment

### Deploy Frontend (Vercel/Netlify)
```bash
npm run build
# Deploy the 'dist' folder
```

### Deploy Backend (Heroku/Railway)
```bash
# Set environment variables
NODE_ENV=production
PORT=<provided by platform>

# Push to git
git push heroku main
```

---

## 🔄 File Upload Feature

Files are temporarily stored in `/backend/uploads/` directory.

To add persistent storage:
- AWS S3
- Google Cloud Storage
- Azure Blob Storage

---

## 🎯 Next Steps for Production

1. **Database**: Replace in-memory with PostgreSQL/MongoDB
2. **Auth**: Add proper password hashing (bcrypt)
3. **PDF Processing**: Integrate pdfjs/pdf-parse
4. **AI Summaries**: Use OpenAI/Gemini API
5. **File Storage**: Use S3/Cloud Storage
6. **Testing**: Add Jest tests
7. **Deployment**: Use Docker containers

---

## 📞 Support

- Check `backend/README.md` for backend details
- Check `src/api.js` for frontend API integration
- Enable browser DevTools for network debugging

---

**Happy Hacking! 🚀**