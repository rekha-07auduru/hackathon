# 🧠 MindLoop - Hackathon Prototype

A lightweight, student-friendly web app prototype for learning management and study assistance.

## Features

- **Login System** - Simple student registration with name, class, and course selection
- **Dashboard** - Quick access to all learning tools
- **Upload Notes** - File upload interface for PDF notes
- **Summary** - Display key concepts and important points
- **Quiz** - Interactive MCQ-based assessment with auto-scoring
- **Flashcards** - Flip-to-reveal study cards for memorization

## Tech Stack

- React.js 18
- Vite (build tool)
- React Router v6 (navigation)
- Vanilla CSS (with gradient theme)

## Quick Start

### Prerequisites
- Node.js 16+ installed

### Installation & Running

```bash
# Navigate to the project directory
cd MindLoop

# Install dependencies
npm install

# Start development server
npm run dev
```

The app will open automatically at `http://localhost:5173`

### Build for Production

```bash
npm run build
npm run preview
```

## Project Structure

```
MindLoop/
├── src/
│   ├── pages/
│   │   ├── Login.jsx
│   │   ├── Home.jsx
│   │   ├── UploadNotes.jsx
│   │   ├── Summary.jsx
│   │   ├── Quiz.jsx
│   │   └── Flashcards.jsx
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── index.html
├── vite.config.js
└── package.json
```

## Usage

1. **Login**: Enter your name, select your class and course
2. **Home**: View all available activities
3. **Upload Notes**: Select a PDF file (UI only, no backend processing)
4. **Summary**: View auto-generated key points
5. **Quiz**: Answer MCQs and see instant results
6. **Flashcards**: Click cards to flip and learn

## Design Theme

- **Colors**: Blue/Purple gradient (#667eea → #764ba2)
- **Layout**: Responsive, mobile-friendly
- **Accessibility**: Simple, clean interface

## Notes

- This is a **UI/UX prototype** for hackathon demonstration
- All data is **dummy/hardcoded** - no backend or database
- No real PDF processing or AI features
- File uploads are for UI demonstration only
- Perfect for showing UI/flow concepts

## License

Open source - hackers welcome!
