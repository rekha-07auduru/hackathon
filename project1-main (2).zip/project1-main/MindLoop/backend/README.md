# MindLoop Backend

Node.js + Express backend for the MindLoop learning platform.

## Features

- User authentication (login/register)
- File upload handling (PDF notes)
- Quiz management and scoring
- Summary generation (dummy data)
- Flashcard system
- User progress tracking
- SQLite database

## Tech Stack

- Express.js
- SQLite3 (database)
- Multer (file uploads)
- JWT (authentication)
- CORS (cross-origin requests)

## Setup & Installation

### Prerequisites
- Node.js 16+ installed

### Installation

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install
```

### Running the Server

```bash
# Development mode with auto-reload
npm run dev

# Production mode
npm start
```

Server will run on `http://localhost:3001`

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login with name, class, course
- `POST /api/auth/register` - Register new student
- `GET /api/auth/me` - Get current user info (requires token)

### Notes
- `POST /api/notes/upload` - Upload PDF file
- `GET /api/notes` - Get user's notes
- `DELETE /api/notes/:id` - Delete a note

### Summary
- `GET /api/summary/:noteId` - Get summary for specific note
- `GET /api/summary` - Get all summaries

### Quiz
- `GET /api/quiz/questions` - Get quiz questions
- `POST /api/quiz/submit` - Submit quiz answers
- `GET /api/quiz/history` - Get quiz history

### Flashcards
- `GET /api/flashcards` - Get all flashcards
- `GET /api/flashcards/set/:setId` - Get specific set
- `POST /api/flashcards/:cardId/learn` - Mark as learned
- `GET /api/flashcards/progress/all` - Get progress

## Database Structure

### Users Table
- id, name, class, course, email, password, created_at

### Notes Table
- id, user_id, filename, filepath, course, uploaded_at

### Quiz Submissions Table
- id, user_id, score, total_questions, submitted_at

### User Progress Table
- id, user_id, activity_type, status, progress_data, updated_at

## File Uploads

Uploaded PDF files are stored in `/uploads` directory.

## Authentication

All protected routes require JWT token in Authorization header:
```
Authorization: Bearer <token>
```

## Environment Variables

```
PORT=3001
JWT_SECRET=mindloop-secret-key-2024
FRONTEND_URL=http://localhost:5173
NODE_ENV=development
```

## Notes

- This is a **hackathon prototype** with dummy data
- No real PDF processing or AI features
- Perfect for UI/flow demonstration
- Easily extensible for production
