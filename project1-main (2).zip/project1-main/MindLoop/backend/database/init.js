// In-memory database for hackathon prototype
let users = []
let notes = []
let quizSubmissions = []
let userProgress = []

export function initializeDatabase() {
  console.log('📊 In-memory database initialized')
}

export function addUser(user) {
  const id = users.length + 1
  const newUser = { ...user, id, created_at: new Date().toISOString() }
  users.push(newUser)
  return newUser
}

export function findUserById(userId) {
  return users.find(u => u.id === parseInt(userId))
}

export function getNoteById(noteId) {
  return notes.find(n => n.id == noteId)
}

export { notes }

export function addNote(noteData) {
  // Support both old format (userId, filename, filepath, course) and new format (noteData object)
  if (typeof noteData === 'string') {
    // Old format for backward compatibility
    const [userId, filename, filepath, course] = arguments
    const id = notes.length + 1
    const newNote = { id, user_id: userId, filename, filepath, course, uploaded_at: new Date().toISOString() }
    notes.push(newNote)
    return newNote
  } else {
    // New format with full note object
    const newNote = { ...noteData }
    notes.push(newNote)
    return newNote
  }
}

export function getUserNotes(userId) {
  return notes.filter(n => n.user_id === userId)
}

export function addQuizSubmission(userId, score, totalQuestions) {
  const id = quizSubmissions.length + 1
  const submission = { id, user_id: userId, score, total_questions: totalQuestions, submitted_at: new Date().toISOString() }
  quizSubmissions.push(submission)
  return submission
}

export function getQuizHistory(userId) {
  return quizSubmissions.filter(q => q.user_id === userId)
}
