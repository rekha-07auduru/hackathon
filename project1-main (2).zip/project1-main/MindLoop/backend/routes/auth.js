import express from 'express'
import { generateToken } from '../middleware/auth.js'

const router = express.Router()

// Login - with simple in-memory check
router.post('/login', async (req, res) => {
  try {
    const { name, studentClass, course } = req.body

    if (!name || !studentClass || !course) {
      return res.status(400).json({ error: 'Missing required fields' })
    }

    // For hackathon: create/use dummy user
    const dummyId = Math.floor(Math.random() * 10000)
    const user = {
      id: dummyId,
      name,
      studentClass,
      course,
      email: `${name.toLowerCase().replace(/\s/g, '')}@mindloop.com`
    }

    const token = generateToken(user.id)

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        studentClass: user.studentClass,
        course: user.course,
        email: user.email
      }
    })
  } catch (error) {
    console.error('Login error:', error)
    res.status(500).json({ error: 'Login failed' })
  }
})

// Register
router.post('/register', async (req, res) => {
  try {
    const { name, studentClass, course, email, password } = req.body

    if (!name || !studentClass || !course) {
      return res.status(400).json({ error: 'Missing required fields' })
    }

    const dummyId = Math.floor(Math.random() * 10000)
    const user = {
      id: dummyId,
      name,
      studentClass,
      course,
      email: email || `${name.toLowerCase().replace(/\s/g, '')}@mindloop.com`
    }

    const token = generateToken(user.id)

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        studentClass: user.studentClass,
        course: user.course,
        email: user.email
      }
    })
  } catch (error) {
    console.error('Register error:', error)
    res.status(500).json({ error: 'Registration failed' })
  }
})

// Get current user
router.get('/me', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1]
    if (!token) {
      return res.status(401).json({ error: 'No token provided' })
    }

    // Return dummy user data
    res.json({
      id: Math.random(),
      name: 'Student',
      studentClass: '5th',
      course: 'Mathematics'
    })
  } catch (error) {
    res.status(500).json({ error: 'Failed to get user' })
  }
})

export default router
