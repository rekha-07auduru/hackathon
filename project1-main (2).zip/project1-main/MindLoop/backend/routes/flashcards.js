import express from 'express'
import { authMiddleware } from '../middleware/auth.js'

const router = express.Router()

// Get all flashcards
router.get('/', authMiddleware, (req, res) => {
  try {
    const flashcards = [
      {
        id: 1,
        front: 'What is Active Learning?',
        back: 'Active learning is an educational approach where students engage directly with the material, ask questions, solve problems, and apply concepts rather than passively listening or reading.'
      },
      {
        id: 2,
        front: 'Define Retention in Learning',
        back: 'Retention is the ability to keep information in memory over time. It improves significantly with practice, spaced repetition, and meaningful comprehension of concepts.'
      },
      {
        id: 3,
        front: 'What does SQ3R method stand for?',
        back: 'SQ3R stands for Survey, Question, Read, Recite, and Review. It is a study technique designed to help learners comprehend and memorize reading materials effectively.'
      },
      {
        id: 4,
        front: 'What is Metacognition?',
        back: 'Metacognition is thinking about thinking - the ability to monitor and reflect on your own learning process, understand your strengths and weaknesses, and adjust strategies accordingly.'
      },
      {
        id: 5,
        front: 'What is the Feynman Technique?',
        back: 'The Feynman Technique is a learning strategy that involves explaining a concept in simple terms to identify gaps in understanding, then revising and simplifying your explanation.'
      },
      {
        id: 6,
        front: 'What are Spaced Repetitions?',
        back: 'Spaced repetitions involve reviewing material at increasing intervals over time. This method leverages the spacing effect to maximize memory retention and long-term learning.'
      }
    ]

    res.json({ success: true, flashcards })
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch flashcards' })
  }
})

// Get specific flashcard set
router.get('/set/:setId', authMiddleware, (req, res) => {
  try {
    const { setId } = req.params

    const flashcardSets = {
      1: {
        setId: 1,
        title: 'Learning Strategies',
        cards: [
          {
            id: 1,
            front: 'What is Active Learning?',
            back: 'Active learning is an educational approach where students engage directly with the material.'
          },
          {
            id: 2,
            front: 'Define Retention',
            back: 'Retention is the ability to keep information in memory over time.'
          }
        ]
      }
    }

    const set = flashcardSets[parseInt(setId)]
    if (!set) {
      return res.status(404).json({ error: 'Flashcard set not found' })
    }

    res.json({ success: true, set })
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch flashcard set' })
  }
})

// Mark flashcard as learned
router.post('/:cardId/learn', authMiddleware, (req, res) => {
  try {
    const { cardId } = req.params

    res.json({
      success: true,
      message: 'Card marked as learned',
      cardId: parseInt(cardId)
    })
  } catch (error) {
    res.status(500).json({ error: 'Failed to mark card as learned' })
  }
})

// Get user's flashcard progress
router.get('/progress/all', authMiddleware, (req, res) => {
  try {
    const progress = {
      totalCards: 30,
      learned: 12,
      inProgress: 18,
      percentage: 40
    }

    res.json({ success: true, progress })
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch progress' })
  }
})

export default router
