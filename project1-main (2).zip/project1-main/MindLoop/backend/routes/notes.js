import express from 'express'
import multer from 'multer'
import { fileURLToPath } from 'url'
import { dirname } from 'path'
import { authMiddleware } from '../middleware/auth.js'
import { extractTextFromPDF, generateQuizFromText, generateSummaryFromText } from '../services/pdfProcessor.js'
import { addNote } from '../database/init.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const router = express.Router()

// Setup multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads/')
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + '-' + file.originalname
    cb(null, uniqueName)
  }
})

const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true)
    } else {
      cb(new Error('Only PDF files are allowed'), false)
    }
  }
})

// Upload PDF notes
router.post('/upload', authMiddleware, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' })
    }

    const { course } = req.body

    // Extract text from PDF
    let pdfText = ''
    try {
      pdfText = await extractTextFromPDF(req.file.path)
    } catch (error) {
      console.error('PDF extraction error:', error)
      pdfText = 'Failed to extract text from PDF'
    }

    // Save note to database
    const noteId = Date.now()
    const userId = req.user?.id || 1 // Fallback user ID for hackathon
    const noteData = {
      id: noteId,
      userId: userId,
      filename: req.file.originalname,
      filepath: req.file.path,
      course: course || 'Unknown',
      uploadedAt: new Date().toISOString(),
      size: req.file.size,
      content: pdfText
    }

    addNote(noteData)

    res.json({
      success: true,
      message: 'File uploaded successfully',
      noteId: noteId,
      file: {
        id: noteId,
        filename: req.file.originalname,
        filepath: req.file.path,
        course: course || 'Unknown',
        uploadedAt: new Date().toISOString(),
        size: req.file.size
      }
    })
  } catch (error) {
    console.error('Upload error:', error)
    res.status(500).json({ error: 'Upload failed' })
  }
})

// Get user's uploaded notes
router.get('/', authMiddleware, (req, res) => {
  try {
    // Return dummy notes data
    const notes = [
      {
        id: 1,
        filename: 'Mathematics_Chapter1.pdf',
        course: 'Mathematics',
        uploadedAt: new Date().toISOString(),
        size: 2024
      },
      {
        id: 2,
        filename: 'Science_Fundamentals.pdf',
        course: 'Science',
        uploadedAt: new Date().toISOString(),
        size: 3048
      }
    ]

    res.json({ success: true, notes })
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch notes' })
  }
})

// Delete notes
router.delete('/:id', authMiddleware, (req, res) => {
  try {
    res.json({
      success: true,
      message: 'Note deleted successfully'
    })
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete note' })
  }
})

export default router
