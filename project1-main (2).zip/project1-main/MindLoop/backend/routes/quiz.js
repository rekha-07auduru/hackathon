import express from 'express'
import { authMiddleware } from '../middleware/auth.js'
import { generateQuizFromText } from '../services/pdfProcessor.js'
import { notes } from '../database/init.js'

const router = express.Router()

// Get quiz questions - intelligently generated from PDF or hardcoded fallback
router.get('/questions', authMiddleware, async (req, res) => {
  try {
    const { noteId } = req.query
    console.log('📝 Quiz endpoint called with noteId:', noteId)

    // If noteId provided, generate questions from PDF content
    if (noteId) {
      try {
        const userId = req.user?.id || 1
        console.log('🔍 Searching for note:', noteId, 'userId:', userId)
        
        // Find the note in database
        const note = notes.find(n => n.id == noteId)
        console.log('📄 Note found:', note ? 'Yes' : 'No')
        
        if (!note) {
          console.log('❌ Note not found, using note ID:', noteId)
          return res.status(404).json({ 
            error: 'Note not found',
            success: false
          })
        }

        // Check if note has content extracted
        if (!note.content) {
          console.log('⚠️ Note found but no content extracted')
          return res.status(400).json({
            error: 'PDF content not extracted',
            success: false
          })
        }

        console.log('✅ Content found, generating questions...')
        console.log('📑 Content length:', note.content.length, 'chars')

        // Generate questions from extracted PDF text
        const generatedQuestions = generateQuizFromText(note.content)
        console.log('🎯 Generated', generatedQuestions.length, 'questions')
        
        // Add IDs to generated questions
        const questionsWithIds = generatedQuestions.map((q, index) => ({
          id: index + 1,
          question: q.question,
          options: q.options,
          correct: q.correct,
          explanation: q.explanation,
          difficulty: q.difficulty
        }))

        return res.json({ 
          success: true, 
          questions: questionsWithIds, 
          source: 'pdf-generated',
          noteId: noteId
        })
      } catch (error) {
        console.error('❌ Error generating questions from PDF:', error)
        // Fall back to hardcoded if generation fails
      }
    }

    console.log('📌 Using fallback hardcoded questions')

    // Fallback to hardcoded questions
    const questions = [
      {
        id: 1,
        question: 'What is the main objective of effective learning?',
        options: [
          'To memorize as much as possible',
          'To understand concepts and apply them practically',
          'To spend the most time studying',
          'To get high marks only'
        ],
        correct: 1,
        difficulty: 'easy'
      },
      {
        id: 2,
        question: 'Which technique is best for retaining information?',
        options: [
          'Reading once and forgetting',
          'Active recall and spaced repetition',
          'Passive listening only',
          'Memorizing without understanding'
        ],
        correct: 1,
        difficulty: 'medium'
      },
      {
        id: 3,
        question: 'How often should you revise your notes?',
        options: [
          'Never',
          'Once a year',
          'Daily and before exams',
          'Only during exams'
        ],
        correct: 2,
        difficulty: 'easy'
      },
      {
        id: 4,
        question: 'What does SQ3R method stand for?',
        options: [
          'Survey, Skim, Study, Search, Summarize',
          'Survey, Question, Read, Recite, Review',
          'Scan, Quick, Read, Recall, Reflect',
          'Source, Query, Reference, Repeat, Review'
        ],
        correct: 1,
        difficulty: 'hard'
      },
      {
        id: 5,
        question: 'Which is the best time to study new material?',
        options: [
          'Late night before bed',
          'When you are most alert and focused',
          'Whenever you have free time',
          'Only during exam preparation'
        ],
        correct: 1,
        difficulty: 'medium'
      }
    ]

    res.json({ success: true, questions, source: 'hardcoded' })
  } catch (error) {
    console.error('❌ Quiz endpoint error:', error)
    res.status(500).json({ 
      error: 'Failed to fetch questions',
      success: false,
      details: error.message
    })
  }
})

// Submit quiz answers and calculate score
router.post('/submit', authMiddleware, (req, res) => {
  try {
    const { answers } = req.body

    if (!answers || typeof answers !== 'object') {
      return res.status(400).json({ error: 'Invalid answers format' })
    }

    // Correct answers mapping (only for hardcoded questions)
    const correctAnswers = {
      1: 1,
      2: 1,
      3: 2,
      4: 1,
      5: 1
    }

    let score = 0
    const totalQuestions = Object.keys(correctAnswers).length

    // Calculate score
    for (const [questionId, selectedOption] of Object.entries(answers)) {
      if (correctAnswers[questionId] === selectedOption) {
        score++
      }
    }

    const percentage = Math.round((score / totalQuestions) * 100)

    // Generate feedback
    let feedback = ''
    if (percentage >= 80) {
      feedback = '🌟 Excellent! You have a great understanding of the material!'
    } else if (percentage >= 60) {
      feedback = '👍 Good job! Keep practicing to improve further.'
    } else {
      feedback = '💪 Keep learning! Review the material and try again.'
    }

    res.json({
      success: true,
      score,
      totalQuestions,
      percentage,
      feedback
    })
  } catch (error) {
    console.error('Error submitting quiz:', error)
    res.status(500).json({ error: 'Failed to submit quiz' })
  }
})

// Get quiz history
router.get('/history', authMiddleware, (req, res) => {
  try {
    res.json({
      success: true,
      history: [
        {
          date: new Date().toISOString(),
          score: 4,
          total: 5,
          percentage: 80
        }
      ]
    })
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch history' })
  }
})

export default router