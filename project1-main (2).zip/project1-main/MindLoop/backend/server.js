import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import { fileURLToPath } from 'url'
import { dirname } from 'path'
import { initializeDatabase } from './database/init.js'
import authRoutes from './routes/auth.js'
import notesRoutes from './routes/notes.js'
import summaryRoutes from './routes/summary.js'
import quizRoutes from './routes/quiz.js'
import flashcardsRoutes from './routes/flashcards.js'

dotenv.config()

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const app = express()


app.use(cors({
  origin: function (origin, callback) {
    if (!origin || origin.includes('localhost') || origin.includes('127.0.0.1')) {
      callback(null, true)
    } else {
      callback(new Error('CORS not allowed'))
    }
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true
}))

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Initialize database
initializeDatabase()

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/notes', notesRoutes)
app.use('/api/summary', summaryRoutes)
app.use('/api/quiz', quizRoutes)
app.use('/api/flashcards', flashcardsRoutes)

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'Backend is running!' })
})

const PORT = process.env.PORT || 3001

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`)
  console.log(`📚 MindLoop Backend Ready!`)
})
