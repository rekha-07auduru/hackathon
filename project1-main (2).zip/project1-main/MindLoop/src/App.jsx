import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { useState } from 'react'
import Login from './pages/Login'
import Home from './pages/Home'
import UploadNotes from './pages/UploadNotes'
import Summary from './pages/Summary'
import Quiz from './pages/Quiz'
import Flashcards from './pages/Flashcards'

function App() {
  const [studentInfo, setStudentInfo] = useState(null)

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login setStudentInfo={setStudentInfo} />} />
        <Route path="/home" element={<Home studentInfo={studentInfo} />} />
        <Route path="/upload" element={<UploadNotes studentInfo={studentInfo} />} />
        <Route path="/summary" element={<Summary studentInfo={studentInfo} />} />
        <Route path="/quiz" element={<Quiz studentInfo={studentInfo} />} />
        <Route path="/flashcards" element={<Flashcards studentInfo={studentInfo} />} />
      </Routes>
    </Router>
  )
}

export default App
