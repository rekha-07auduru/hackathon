const API_BASE_URL = 'http://localhost:3001/api'

// Store token in localStorage
export function setToken(token) {
  localStorage.setItem('mindloop_token', token)
}

export function getToken() {
  return localStorage.getItem('mindloop_token')
}

export function removeToken() {
  localStorage.removeItem('mindloop_token')
}

export function getAuthHeader() {
  const token = getToken()
  return token ? { Authorization: `Bearer ${token}` } : {}
}

// Auth API calls
export async function login(name, studentClass, course) {
  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, studentClass, course })
  })
  const data = await response.json()
  if (data.token) {
    setToken(data.token)
  }
  return data
}

export async function register(name, studentClass, course) {
  const response = await fetch(`${API_BASE_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, studentClass, course })
  })
  const data = await response.json()
  if (data.token) {
    setToken(data.token)
  }
  return data
}

export async function getCurrentUser() {
  const response = await fetch(`${API_BASE_URL}/auth/me`, {
    headers: getAuthHeader()
  })
  return await response.json()
}

// Notes API calls
export async function uploadNotes(formData) {
  const response = await fetch(`${API_BASE_URL}/notes/upload`, {
    method: 'POST',
    headers: getAuthHeader(),
    body: formData
  })
  return await response.json()
}

export async function getUserNotes() {
  const response = await fetch(`${API_BASE_URL}/notes`, {
    headers: getAuthHeader()
  })
  return await response.json()
}

export async function deleteNote(noteId) {
  const response = await fetch(`${API_BASE_URL}/notes/${noteId}`, {
    method: 'DELETE',
    headers: getAuthHeader()
  })
  return await response.json()
}

// Summary API calls
export async function getSummary(noteId) {
  const response = await fetch(`${API_BASE_URL}/summary/${noteId}`, {
    headers: getAuthHeader()
  })
  return await response.json()
}

export async function getAllSummaries() {
  const response = await fetch(`${API_BASE_URL}/summary`, {
    headers: getAuthHeader()
  })
  return await response.json()
}

// Quiz API calls
export async function getQuizQuestions(noteId) {
  const url = noteId 
    ? `${API_BASE_URL}/quiz/questions?noteId=${noteId}`
    : `${API_BASE_URL}/quiz/questions`
  
  const response = await fetch(url, {
    headers: getAuthHeader()
  })
  return await response.json()
}

export async function submitQuiz(answers) {
  const response = await fetch(`${API_BASE_URL}/quiz/submit`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeader()
    },
    body: JSON.stringify({ answers })
  })
  return await response.json()
}

export async function getQuizHistory() {
  const response = await fetch(`${API_BASE_URL}/quiz/history`, {
    headers: getAuthHeader()
  })
  return await response.json()
}

// Flashcards API calls
export async function getFlashcards() {
  const response = await fetch(`${API_BASE_URL}/flashcards`, {
    headers: getAuthHeader()
  })
  return await response.json()
}

export async function getFlashcardSet(setId) {
  const response = await fetch(`${API_BASE_URL}/flashcards/set/${setId}`, {
    headers: getAuthHeader()
  })
  return await response.json()
}

export async function markCardAsLearned(cardId) {
  const response = await fetch(`${API_BASE_URL}/flashcards/${cardId}/learn`, {
    method: 'POST',
    headers: getAuthHeader()
  })
  return await response.json()
}

export async function getFlashcardProgress() {
  const response = await fetch(`${API_BASE_URL}/flashcards/progress/all`, {
    headers: getAuthHeader()
  })
  return await response.json()
}
