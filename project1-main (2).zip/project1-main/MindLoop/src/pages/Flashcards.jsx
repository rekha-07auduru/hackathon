import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { getFlashcards } from '../api'

export default function Flashcards({ studentInfo }) {
  const [flashcards, setFlashcards] = useState([])
  const [currentCardIndex, setCurrentCardIndex] = useState(0)
  const [isFlipped, setIsFlipped] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    if (!studentInfo) {
      navigate('/')
      return
    }

    const loadFlashcards = async () => {
      try {
        const response = await getFlashcards()
        if (response.success && response.flashcards) {
          setFlashcards(response.flashcards)
        } else {
          setError('Failed to load flashcards')
        }
      } catch (err) {
        setError('Connection error: Backend not running?')
        console.error('Error loading flashcards:', err)
      } finally {
        setLoading(false)
      }
    }

    loadFlashcards()
  }, [studentInfo, navigate])

  const currentCard = flashcards.length > 0 ? flashcards[currentCardIndex] : null

  const handleNext = () => {
    if (currentCardIndex < flashcards.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1)
      setIsFlipped(false)
    }
  }

  const handlePrev = () => {
    if (currentCardIndex > 0) {
      setCurrentCardIndex(currentCardIndex - 1)
      setIsFlipped(false)
    }
  }

  const handleFlip = () => {
    setIsFlipped(!isFlipped)
  }

  return (
    <div>
      <div className="header">
        <h1>Flashcards</h1>
        <p>{studentInfo.course} | {studentInfo.studentClass}</p>
      </div>

      <div className="container">
        <div className="card">
          {error && (
            <div style={{
              background: '#ffebee',
              color: '#d32f2f',
              padding: '12px',
              borderRadius: '6px',
              marginBottom: '15px'
            }}>
              {error}
            </div>
          )}

          {loading && (
            <div style={{ textAlign: 'center', padding: '40px' }}>
              <p>Loading flashcards...</p>
            </div>
          )}

          {!loading && flashcards.length > 0 && currentCard ? (
            <>
              <h2>📚 Study with Flashcards</h2>

              <div style={{ marginTop: '20px', textAlign: 'center' }}>
                <p style={{ color: '#999', marginBottom: '15px' }}>
                  Card {currentCardIndex + 1} of {flashcards.length}
                </p>

            <div
              className="flashcard"
              onClick={handleFlip}
              style={{
                minHeight: '250px',
                background: isFlipped
                  ? 'linear-gradient(135deg, #764ba2 0%, #667eea 100%)'
                  : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              }}
            >
              <div>
                <p style={{ fontSize: '14px', opacity: 0.7, marginBottom: '20px' }}>
                  {isFlipped ? 'Answer' : 'Question'}
                </p>
                <h3 style={{ fontSize: '22px', fontWeight: '600' }}>
                  {isFlipped ? currentCard.back : currentCard.front}
                </h3>
                <p className="card-flip-hint">Click to flip</p>
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginTop: '20px' }}>
            <button
              onClick={handlePrev}
              disabled={currentCardIndex === 0}
              style={{
                opacity: currentCardIndex === 0 ? 0.5 : 1,
                cursor: currentCardIndex === 0 ? 'not-allowed' : 'pointer'
              }}
            >
              ← Previous
            </button>

            <button
              onClick={handleNext}
              disabled={currentCardIndex === flashcards.length - 1}
              style={{
                opacity: currentCardIndex === flashcards.length - 1 ? 0.5 : 1,
                cursor: currentCardIndex === flashcards.length - 1 ? 'not-allowed' : 'pointer'
              }}
            >
              Next →
            </button>
          </div>

          <div style={{ marginTop: '15px', textAlign: 'center' }}>
            {Array.from({ length: flashcards.length }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setCurrentCardIndex(idx)
                  setIsFlipped(false)
                }}
                style={{
                  width: '40px',
                  height: '40px',
                  margin: '0 5px',
                  background:
                    idx === currentCardIndex
                      ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                      : '#f0f0f0',
                  color: idx === currentCardIndex ? 'white' : '#333',
                  border: 'none',
                  borderRadius: '50%',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '600'
                }}
              >
                {idx + 1}
              </button>
            ))}
          </div>

          <button
            className="btn-secondary back-button"
            onClick={() => navigate('/home')}
          >
            Back to Home
          </button>
            </>
          ) : !loading && flashcards.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '20px' }}>
              <p>No flashcards available</p>
              <button
                className="btn-secondary"
                onClick={() => navigate('/home')}
              >
                Back to Home
              </button>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  )
}
