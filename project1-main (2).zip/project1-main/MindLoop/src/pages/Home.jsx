import { useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'

const homeStyles = {
  mainContainer: {
    display: 'grid',
    gridTemplateColumns: '1fr 280px',
    gap: '20px',
    padding: '20px'
  },
  leftSection: {
    flex: 1
  },
  pointsCard: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    padding: '25px',
    borderRadius: '12px',
    boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3)',
    textAlign: 'center',
    position: 'sticky',
    top: '20px'
  },
  pointsNumber: {
    fontSize: '48px',
    fontWeight: 'bold',
    margin: '15px 0',
    textShadow: '0 2px 10px rgba(0,0,0,0.2)'
  },
  starsContainer: {
    fontSize: '32px',
    marginBottom: '15px',
    letterSpacing: '8px'
  },
  levelBadge: {
    display: 'inline-block',
    background: 'rgba(255,255,255,0.2)',
    padding: '8px 16px',
    borderRadius: '20px',
    fontSize: '12px',
    fontWeight: '600',
    marginTop: '10px',
    backdropFilter: 'blur(10px)'
  },
  encouragingText: {
    fontSize: '14px',
    marginTop: '12px',
    fontStyle: 'italic',
    opacity: 0.95,
    lineHeight: '1.4'
  },
  milestoneEmoji: {
    fontSize: '24px',
    marginTop: '10px',
    animation: 'bounce 0.6s'
  },
  header: {
    position: 'relative',
    textAlign: 'center',
    marginBottom: '40px',
    color: '#667eea'
  },
  logoutBtn: {
    position: 'absolute',
    top: '0px',
    right: '20px',
    padding: '8px 16px',
    background: '#ff6b6b',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontWeight: '600',
    fontSize: '14px',
    transition: 'background 0.3s'
  },
  card: {
    background: 'white',
    padding: '40px',
    borderRadius: '12px',
    boxShadow: '0 4px 20px rgba(102, 126, 234, 0.2)'
  },
  gridContainer: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '15px',
    marginTop: '30px'
  },
  generateBtn: {
    padding: '30px 20px',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '18px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.3s',
    boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3)'
  },
  uploadBtn: {
    marginTop: '30px',
    padding: '12px 24px',
    background: '#f0f0f0',
    color: '#333',
    border: '2px solid #ddd',
    borderRadius: '6px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.3s'
  },
  fullWidthBtn: {
    gridColumn: '1 / -1'
  }
}

const getPointsLevel = (points) => {
  if (points < 50) return { level: 'Beginner', emoji: '🌱', message: 'Keep learning!' }
  if (points < 150) return { level: 'Growing', emoji: '🌿', message: 'You\'re progressing!' }
  if (points < 300) return { level: 'Advanced', emoji: '🌳', message: 'Amazing progress!' }
  if (points < 500) return { level: 'Expert', emoji: '🏆', message: 'You\'re a star!' }
  return { level: 'Master', emoji: '👑', message: 'You\'re unstoppable!' }
}

const getStars = (points) => {
  const fullStars = Math.floor(points / 100)
  const emptyStars = Math.max(0, 5 - fullStars)
  return '⭐'.repeat(Math.min(fullStars, 5)) + '☆'.repeat(emptyStars)
}

export default function Home({ studentInfo }) {
  const navigate = useNavigate()
  const [points, setPoints] = useState(0)
  const [showMilestone, setShowMilestone] = useState(false)

  useEffect(() => {
    // Load points from localStorage
    const savedPoints = localStorage.getItem('studentPoints') || '0'
    setPoints(parseInt(savedPoints))
  }, [])

  useEffect(() => {
    // Save points to localStorage
    localStorage.setItem('studentPoints', points.toString())
  }, [points])

  if (!studentInfo) {
    navigate('/')
    return null
  }

  const levelInfo = getPointsLevel(points)
  const stars = getStars(points)

  const handleActivityClick = (activity) => {
    // Add points for attempting activities
    const pointsEarned = 25
    setPoints(points + pointsEarned)
    setShowMilestone(true)
    setTimeout(() => setShowMilestone(false), 1500)
    navigate(activity)
  }

  return (
    <div>
      <style>{`
        @keyframes bounce {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.2); }
        }
        @keyframes slideInRight {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        .points-milestone {
          animation: slideInRight 0.5s ease-out;
        }
        .header .btn-logout:hover {
          background: #ff5252;
        }
        .generate-btn:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        .generate-btn:active {
          transform: translateY(0);
        }
        @media (max-width: 768px) {
          .main-container {
            grid-template-columns: 1fr !important;
          }
          .points-card {
            position: static !important;
          }
        }
      `}</style>

      <div style={homeStyles.mainContainer} className="main-container">
        <div style={homeStyles.leftSection}>
          <div className="header" style={homeStyles.header}>
            <h1>🧠 MindLoop</h1>
            <p>Welcome, {studentInfo?.name || 'Student'}! 👋</p>
            <button
              className="btn-logout"
              style={homeStyles.logoutBtn}
              onClick={() => navigate('/')}
              onMouseEnter={(e) => e.target.style.background = '#ff5252'}
              onMouseLeave={(e) => e.target.style.background = '#ff6b6b'}
            >
              Logout
            </button>
          </div>

          <div style={homeStyles.card}>
            <h2 style={{ color: '#667eea', marginBottom: '10px' }}>Select What To Generate</h2>
            <p style={{ color: '#999', fontSize: '14px', marginBottom: '30px' }}>
              Choose a study tool to get started and earn points! 🎯
            </p>

            <div style={homeStyles.gridContainer}>
              <button
                className="generate-btn"
                onClick={() => handleActivityClick('/summary')}
                style={homeStyles.generateBtn}
                onMouseEnter={(e) => (e.target.style.transform = 'translateY(-3px)')}
                onMouseLeave={(e) => (e.target.style.transform = 'translateY(0)')}
              >
                📝 Summary
              </button>

              <button
                className="generate-btn"
                onClick={() => handleActivityClick('/quiz')}
                style={homeStyles.generateBtn}
                onMouseEnter={(e) => (e.target.style.transform = 'translateY(-3px)')}
                onMouseLeave={(e) => (e.target.style.transform = 'translateY(0)')}
              >
                ✍️ Quiz
              </button>

              <button
                className="generate-btn"
                onClick={() => handleActivityClick('/flashcards')}
                style={homeStyles.generateBtn}
                onMouseEnter={(e) => (e.target.style.transform = 'translateY(-3px)')}
                onMouseLeave={(e) => (e.target.style.transform = 'translateY(0)')}
              >
                🎴 Flashcards
              </button>

              <button
                className="generate-btn"
                onClick={() => {
                  setPoints(points + 25)
                  setShowMilestone(true)
                  setTimeout(() => setShowMilestone(false), 1500)
                  alert('MCQs feature coming soon!')
                }}
                style={homeStyles.generateBtn}
                onMouseEnter={(e) => (e.target.style.transform = 'translateY(-3px)')}
                onMouseLeave={(e) => (e.target.style.transform = 'translateY(0)')}
              >
                ❓ MCQs
              </button>

              <button
                className="generate-btn"
                onClick={() => {
                  setPoints(points + 25)
                  setShowMilestone(true)
                  setTimeout(() => setShowMilestone(false), 1500)
                  alert('Fill in Blanks feature coming soon!')
                }}
                style={{ ...homeStyles.generateBtn, ...homeStyles.fullWidthBtn }}
                onMouseEnter={(e) => (e.target.style.transform = 'translateY(-3px)')}
                onMouseLeave={(e) => (e.target.style.transform = 'translateY(0)')}
              >
                📋 Fill in Blanks
              </button>
            </div>

            <button
              style={homeStyles.uploadBtn}
              onClick={() => navigate('/upload')}
            >
              + Upload New Notes
            </button>
          </div>
        </div>

        {/* Points Card - Right Sidebar */}
        <div style={homeStyles.pointsCard} className="points-card">
          <div style={{ fontSize: '20px', fontWeight: '600' }}>Your Score</div>
          
          <div style={homeStyles.starsContainer}>
            {stars}
          </div>

          <div style={homeStyles.pointsNumber}>
            {points}
          </div>

          <div style={{ fontSize: '12px', opacity: 0.9 }}>points earned</div>

          <div style={homeStyles.levelBadge}>
            <span style={{ marginRight: '8px' }}>{levelInfo.emoji}</span>
            {levelInfo.level}
          </div>

          <div style={homeStyles.encouragingText}>
            {levelInfo.message}
          </div>

          {showMilestone && (
            <div style={homeStyles.milestoneEmoji} className="points-milestone">
              +25 ⭐
            </div>
          )}

          <div style={{ marginTop: '20px', fontSize: '12px', opacity: 0.85, lineHeight: '1.6' }}>
            <p>📊 <strong>Progress:</strong></p>
            <p>{Math.floor((points / 500) * 100)}% to Master</p>
            <div style={{
              background: 'rgba(255,255,255,0.2)',
              height: '6px',
              borderRadius: '3px',
              marginTop: '8px',
              overflow: 'hidden'
            }}>
              <div style={{
                background: 'rgba(255,255,255,0.8)',
                height: '100%',
                width: `${Math.min((points / 500) * 100, 100)}%`,
                transition: 'width 0.5s ease'
              }}></div>
            </div>
          </div>

          <div style={{ marginTop: '20px', fontSize: '11px', opacity: 0.8, borderTop: '1px solid rgba(255,255,255,0.2)', paddingTop: '15px' }}>
            <p>💡 Tip: Complete activities to earn more points!</p>
          </div>
        </div>
      </div>
    </div>
  )
}