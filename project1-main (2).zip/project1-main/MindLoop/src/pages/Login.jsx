import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { login } from '../api'

export default function Login({ setStudentInfo }) {
  const [name, setName] = useState('')
  const [studentClass, setStudentClass] = useState('')
  const [course, setCourse] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      if (!name || !studentClass || !course) {
        setError('Please fill in all fields')
        setLoading(false)
        return
      }

      const response = await login(name, studentClass, course)

      if (response.success) {
        setStudentInfo(response.user)
        navigate('/home')
      } else {
        setError(response.error || 'Login failed')
      }
    } catch (err) {
      setError('Connection error. Is backend running on port 3001?')
      console.error('Login error:', err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container" style={{ marginTop: '80px' }}>
      <div className="card">
        <h1>🧠 MindLoop </h1>
      <p className="welcome-text">Learn-Test-Improve</p>

        {error && (
          <div style={{
            background: '#ffebee',
            color: '#d32f2f',
            padding: '12px',
            borderRadius: '6px',
            marginBottom: '15px',
            fontSize: '14px'
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label htmlFor="name">Student Name</label>
            <input
              id="name"
              type="text"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="class">Class</label>
            <select
              id="class"
              value={studentClass}
              onChange={(e) => setStudentClass(e.target.value)}
              required
              disabled={loading}
            >
              <option value="">Select your class</option>
              <option value="6TH">6TH Grade</option>
              <option value="7TH">7TH Grade</option>
              <option value="8TH">8th Grade</option>
              <option value="9TH">9th Grade</option>
              <option value="10TH">10th Grade</option>
              <option value="11TH">11th Grade</option>
              <option value="12TH">12th Grade</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="course">Course</label>
            <select
              id="course"
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              required
              disabled={loading}
            >
              <option value="">Select your course</option>
              <option value="Mathematics">Mathematics</option>
              <option value="English">English</option>
              <option value="Physics">Physics </option>
              <option value="Biology">Biology </option>
              <option value="Chemistry">Chemistry</option>
              <option value="History">History</option>
              <option value="Geography">Geography</option>
            </select>
          </div>

          <button type="submit" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>
      </div>
    </div>
  )
}
