import { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { getQuizQuestions, submitQuiz } from '../api'

export default function Quiz({ studentInfo }) {
  const [questions, setQuestions] = useState([])
  const [answers, setAnswers] = useState({})
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [result, setResult] = useState(null)
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const noteId = searchParams.get('noteId')

  useEffect(() => {
    if (!studentInfo) {
      navigate('/')
      return
    }

    const loadQuestions = async () => {
      try {
        const response = await getQuizQuestions(noteId)
        if (response.success) {
          setQuestions(response.questions)
        } else {
          setError('Failed to load questions')
        }
      } catch (err) {
        setError('Connection error: Backend not running?')
        console.error('Error loading questions:', err)
      } finally {
        setLoading(false)
      }
    }

    loadQuestions()
  }, [studentInfo, navigate, noteId])

  const handleAnswerChange = (questionId, optionIndex) => {
    setAnswers({
      ...answers,
      [questionId]: optionIndex
    })
  }

  const handleSubmit = async () => {
    try {
      setLoading(true)
      const response = await submitQuiz(answers)
      if (response.success) {
        setResult(response)
        setSubmitted(true)
      } else {
        setError('Failed to submit quiz')
      }
    } catch (err) {
      setError('Connection error while submitting')
      console.error('Submit error:', err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <div className="header">
        <h1>🤖 AI Quiz Bot</h1>
        <p>{studentInfo.course} | {studentInfo.studentClass}</p>
      </div>

      <div className="container">
        <div className="card">
          {error && (
            <div style={{
              background: '#ffebee',
              color: '#d32f2f',
              padding: '12px',
              borderRadius: '6px',
              marginBottom: '15px'
            }}>
              {error}
            </div>
          )}

          {loading && !submitted && (
            <div style={{ textAlign: 'center', padding: '40px' }}>
              <p>🤖 AI Bot is reading your PDF and generating smart questions...</p>
            </div>
          )}

          {!loading && !submitted && questions.length > 0 ? (
            <>
              <div style={{ backgroundColor: '#f0f7ff', padding: '15px', borderRadius: '8px', marginBottom: '20px' }}>
                <h2>✨ AI-Generated Quiz from Your Document</h2>
                <p style={{ color: '#667eea', marginBottom: '0' }}>
                  {questions.length} intelligent questions • Varying difficulty levels • Detailed explanations included
                </p>
              </div>

              {questions.map((q, idx) => (
                <div key={q.id} className="quiz-question" style={{
                  border: '1px solid #e0e0e0',
                  padding: '20px',
                  marginBottom: '20px',
                  borderRadius: '8px',
                  backgroundColor: '#fafafa'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '15px' }}>
                    <h3 style={{ margin: '0' }}>Question {idx + 1}</h3>
                    <span style={{
                      backgroundColor: q.difficulty === 'easy' ? '#d4edda' : q.difficulty === 'medium' ? '#fff3cd' : '#f8d7da',
                      color: q.difficulty === 'easy' ? '#155724' : q.difficulty === 'medium' ? '#856404' : '#721c24',
                      padding: '4px 12px',
                      borderRadius: '20px',
                      fontSize: '12px',
                      fontWeight: 'bold'
                    }}>
                      {q.difficulty?.toUpperCase() || 'MEDIUM'}
                    </span>
                  </div>
                  
                  <p style={{ marginBottom: '15px', color: '#333', fontSize: '16px', fontWeight: '500' }}>
                    {q.question}
                  </p>

                  <div style={{ marginBottom: '15px' }}>
                    {q.options.map((option, optionIdx) => (
                      <label
                        key={optionIdx}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          marginBottom: '12px',
                          cursor: 'pointer',
                          padding: '10px',
                          borderRadius: '6px',
                          backgroundColor: answers[q.id] === optionIdx ? '#e3f2fd' : 'white',
                          border: answers[q.id] === optionIdx ? '2px solid #667eea' : '1px solid #ddd'
                        }}
                      >
                        <input
                          type="radio"
                          name={`question-${q.id}`}
                          checked={answers[q.id] === optionIdx}
                          onChange={() => handleAnswerChange(q.id, optionIdx)}
                          style={{ marginRight: '10px', cursor: 'pointer', width: '18px', height: '18px' }}
                        />
                        <span>{option}</span>
                      </label>
                    ))}
                  </div>

                  <div style={{
                    backgroundColor: '#f5f5f5',
                    padding: '10px',
                    borderRadius: '6px',
                    fontSize: '14px',
                    color: '#666',
                    borderLeft: '3px solid #667eea'
                  }}>
                    <strong>💡 Tip:</strong> {q.explanation}
                  </div>
                </div>
              ))}

              <button onClick={handleSubmit} disabled={loading} style={{
                marginTop: '20px',
                padding: '12px 30px',
                backgroundColor: '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '16px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }}>
                {loading ? '⏳ Submitting...' : '✅ Submit Quiz'}
              </button>
            </>
          ) : submitted && result ? (
            <>
              <h2>🎉 Quiz Completed!</h2>

              <div className="score-display" style={{
                backgroundColor: '#f0f7ff',
                padding: '30px',
                borderRadius: '8px',
                marginBottom: '20px',
                textAlign: 'center'
              }}>
                <h2 style={{ margin: '0 0 10px 0' }}>Your Score</h2>
                <div style={{
                  fontSize: '48px',
                  fontWeight: 'bold',
                  color: '#667eea',
                  marginBottom: '10px'
                }}>
                  {result.score}/{result.totalQuestions}
                </div>
                <p style={{ fontSize: '18px', marginBottom: '10px', color: '#333' }}>
                  {result.percentage}% Correct
                </p>
                <p style={{ fontSize: '16px', color: '#666', marginBottom: '0' }}>{result.feedback}</p>
              </div>

              <div style={{
                backgroundColor: '#e8f5e9',
                padding: '20px',
                borderRadius: '8px',
                marginBottom: '20px',
                borderLeft: '4px solid #4caf50'
              }}>
                <h3 style={{ margin: '0 0 10px 0', color: '#2e7d32' }}>📊 Performance Summary</h3>
                <p style={{ color: '#555' }}>
                  You answered <strong>{result.score}</strong> out of <strong>{result.totalQuestions}</strong> questions correctly.
                </p>
                <p style={{ color: '#666', fontSize: '14px' }}>
                  {result.percentage >= 80 ? '🌟 Excellent performance!' : result.percentage >= 60 ? '👍 Good effort!' : '💪 Keep practicing!'}
                </p>
              </div>

              <button onClick={() => navigate('/flashcards')} style={{
                marginRight: '10px',
                padding: '12px 25px',
                backgroundColor: '#4caf50',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '16px',
                cursor: 'pointer'
              }}>
                📚 Learn with Flashcards
              </button>

              <button
                className="btn-secondary back-button"
                onClick={() => navigate('/home')}
                style={{ padding: '12px 25px', marginTop: '10px' }}
              >
                🏠 Back to Home
              </button>
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '20px' }}>
              <p>No questions available</p>
              <button
                className="btn-secondary"
                onClick={() => navigate('/home')}
              >
                Back to Home
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
