import { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { getSummary } from '../api.js'

export default function Summary({ studentInfo }) {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [summaryData, setSummaryData] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const noteId = searchParams.get('noteId')

  if (!studentInfo) {
    navigate('/')
    return null
  }

  useEffect(() => {
    if (noteId) {
      fetchSummary()
    }
  }, [noteId])

  const fetchSummary = async () => {
    setIsLoading(true)
    setError('')
    try {
      const response = await getSummary(noteId)
      if (response.success) {
        setSummaryData(response.summary)
      } else {
        setError('Failed to load summary. Please try again.')
      }
    } catch (err) {
      console.error('Error fetching summary:', err)
      setError('Error loading summary. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  // Default summary if no noteId or not loaded yet
  const defaultSummaryText = `This is a comprehensive overview of the key concepts and topics covered in your ${studentInfo.course} course. The summary is generated to help you understand the main ideas and important points that will be essential for your learning journey.`

  const defaultImportantPoints = [
    '🔑 Understanding the fundamental concepts is crucial for mastering this subject',
    '📊 Practice regularly to reinforce your learning and improve retention',
    '🎯 Focus on the key definitions and formulas that frequently appear in exams',
    '💡 Connect new concepts with previous learning to build a strong foundation'
  ]

  const summaryText = summaryData?.overview || defaultSummaryText
  const importantPoints = summaryData?.importantPoints || defaultImportantPoints

  return (
    <div>
      <div className="header">
        <h1>🤖 AI Document Analysis</h1>
        <p>{studentInfo.course} | {studentInfo.studentClass}</p>
      </div>

      <div className="container">
        <div className="card">
          {isLoading && (
            <div style={{ textAlign: 'center', padding: '40px' }}>
              <p>🤖 AI Bot is analyzing your PDF document...</p>
              <p style={{ fontSize: '14px', color: '#999' }}>Extracting content, identifying key concepts, and preparing learning materials...</p>
            </div>
          )}

          {error && (
            <div style={{ color: '#e74c3c', marginBottom: '20px', padding: '10px', backgroundColor: '#fadbd8', borderRadius: '4px' }}>
              {error}
            </div>
          )}

          {!isLoading && (
            <>
              <div style={{ backgroundColor: '#f0f7ff', padding: '20px', borderRadius: '8px', marginBottom: '20px' }}>
                <h2 style={{ margin: '0 0 10px 0' }}>📚 AI Analysis Summary</h2>
                <p style={{ color: '#667eea', margin: '0' }}>Your document has been analyzed and processed by the learning bot</p>
              </div>

              <h2 style={{ marginTop: '30px', color: '#333' }}>📖 Overview</h2>
              <div style={{
                backgroundColor: '#f9f9f9',
                padding: '15px',
                borderRadius: '8px',
                borderLeft: '4px solid #667eea',
                marginBottom: '20px'
              }}>
                <p style={{ margin: '0', lineHeight: '1.6', color: '#555' }}>
                  {summaryText}
                </p>
              </div>

              <h2 style={{ marginTop: '30px', color: '#333' }}>⭐ Key Learning Points</h2>
              <div className="points-list">
                {importantPoints.map((point, index) => (
                  <div key={index} className="point" style={{
                    backgroundColor: '#f5f5f5',
                    padding: '12px',
                    marginBottom: '10px',
                    borderRadius: '6px',
                    borderLeft: '4px solid #4caf50'
                  }}>
                    {point}
                  </div>
                ))}
              </div>

              {summaryData?.insights && (
                <>
                  <h2 style={{ marginTop: '30px', color: '#333' }}>📊 Content Insights</h2>
                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                    gap: '15px',
                    marginBottom: '20px'
                  }}>
                    <div style={{
                      backgroundColor: '#e8f5e9',
                      padding: '15px',
                      borderRadius: '8px',
                      textAlign: 'center'
                    }}>
                      <p style={{ margin: '0 0 5px 0', color: '#999', fontSize: '12px' }}>Content Complexity</p>
                      <p style={{ margin: '0', fontSize: '18px', fontWeight: 'bold', color: '#2e7d32' }}>
                        {summaryData?.insights?.complexity}
                      </p>
                    </div>
                    <div style={{
                      backgroundColor: '#e3f2fd',
                      padding: '15px',
                      borderRadius: '8px',
                      textAlign: 'center'
                    }}>
                      <p style={{ margin: '0 0 5px 0', color: '#999', fontSize: '12px' }}>Topics Covered</p>
                      <p style={{ margin: '0', fontSize: '18px', fontWeight: 'bold', color: '#1565c0' }}>
                        {summaryData?.insights?.topicDensity}
                      </p>
                    </div>
                    <div style={{
                      backgroundColor: '#fff3e0',
                      padding: '15px',
                      borderRadius: '8px',
                      textAlign: 'center'
                    }}>
                      <p style={{ margin: '0 0 5px 0', color: '#999', fontSize: '12px' }}>Estimated Reading Time</p>
                      <p style={{ margin: '0', fontSize: '18px', fontWeight: 'bold', color: '#e65100' }}>
                        {summaryData?.insights?.readingTime}
                      </p>
                    </div>
                  </div>

                  <div style={{
                    backgroundColor: '#f3e5f5',
                    padding: '15px',
                    borderRadius: '8px',
                    marginBottom: '20px'
                  }}>
                    <p style={{ margin: '0', color: '#6a1b9a' }}>
                      💡 <strong>Recommended Approach:</strong> {summaryData?.insights?.recommendedApproach}
                    </p>
                  </div>
                </>
              )}

              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '30px' }}>
                <button 
                  onClick={() => navigate(`/quiz${noteId ? `?noteId=${noteId}` : ''}`)} 
                  style={{
                    padding: '12px 25px',
                    backgroundColor: '#667eea',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontWeight: 'bold'
                  }}
                >
                  📝 Take AI Quiz
                </button>

                <button
                  className="btn-secondary back-button"
                  onClick={() => navigate('/home')}
                  style={{ padding: '12px 25px' }}
                >
                  🏠 Back to Home
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
