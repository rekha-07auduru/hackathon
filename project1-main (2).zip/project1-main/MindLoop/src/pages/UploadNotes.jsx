import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { uploadNotes } from '../api.js'

export default function UploadNotes({ studentInfo }) {
  const [fileName, setFileName] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const fileInputRef = useRef(null)
  const navigate = useNavigate()

  if (!studentInfo) {
    navigate('/')
    return null
  }

  const handleFileChange = (e) => {
    if (e.target.files[0]) {
      setFileName(e.target.files[0].name)
      setError('')
    }
  }

  const handleProcessNotes = async () => {
    if (!fileInputRef.current?.files[0]) {
      setError('Please select a PDF file first')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      const formData = new FormData()
      formData.append('file', fileInputRef.current.files[0])
      formData.append('course', studentInfo.course || 'General')

      const response = await uploadNotes(formData)

      if (response.success) {
        // Navigate to summary page with noteId
        navigate(`/summary?noteId=${response.noteId}`)
      } else {
        setError('Failed to upload file. Please try again.')
      }
    } catch (err) {
      console.error('Upload error:', err)
      setError('Error uploading file. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div>
      <div className="header">
        <h1>Upload Notes</h1>
        <p>{studentInfo.course} | {studentInfo.studentClass}</p>
      </div>

      <div className="container">
        <div className="card">
          <h2>Upload Your PDF Notes</h2>
          <p style={{ color: '#777', marginBottom: '20px' }}>
            Upload PDF files to get summaries, quizzes, and flashcards automatically generated.
          </p>

          <div className="file-input-wrapper">
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf"
              onChange={handleFileChange}
              id="file-input"
              disabled={isLoading}
            />
            <label htmlFor="file-input" className="file-label">
              📁 Click to upload PDF or drag and drop
              <br />
              <small style={{ color: '#999', marginTop: '10px', display: 'block' }}>
                .pdf files only
              </small>
            </label>
          </div>

          {fileName && (
            <div className="file-name">
              ✓ File selected: {fileName}
            </div>
          )}

          {error && (
            <div style={{ color: '#e74c3c', marginTop: '15px', padding: '10px', backgroundColor: '#fadbd8', borderRadius: '4px' }}>
              {error}
            </div>
          )}

          <button 
            onClick={handleProcessNotes} 
            style={{ marginTop: '20px' }}
            disabled={isLoading}
          >
            {isLoading ? '⏳ Processing...' : 'Process Notes'}
          </button>

          <button
            className="btn-secondary back-button"
            onClick={() => navigate('/home')}
            disabled={isLoading}
          >
            Back to Home
          </button>
        </div>
      </div>
    </div>
  )
}
