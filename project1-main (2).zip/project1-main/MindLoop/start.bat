@echo off
REM MindLoop - Full Stack Startup Script for Windows

color 0A
cls
echo.
echo ======================================================
echo 🧠  MindLoop - Full Stack Hackathon Prototype
echo ======================================================
echo.

REM Start Backend
echo [1/2] Starting Backend on port 3001...
echo.
start "MindLoop Backend" cmd /k "cd backend && npm start"

timeout /t 3 /nobreak

REM Start Frontend
echo [2/2] Starting Frontend on port 5173...
echo.
start "MindLoop Frontend" cmd /k "npm run dev"

timeout /t 2 /nobreak

REM Open browser
echo.
echo ======================================================
echo ✅ Services Started!
echo ======================================================
echo.
echo 📱 Frontend:  http://localhost:5173
echo 🔌 Backend:   http://localhost:3001
echo.
echo Opening browser...
start http://localhost:5173

echo.
echo Services are running in separate windows.
echo Close the command windows to stop.
echo.
pause
