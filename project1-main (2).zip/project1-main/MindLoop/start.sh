#!/bin/bash

# MindLoop - Full Stack Startup Script

echo "🚀 Starting MindLoop Full Stack..."
echo ""

# Start Backend
echo "📦 Starting Backend on port 3001..."
cd backend
npm install &> /dev/null
npm start &
BACKEND_PID=$!
echo "✅ Backend started (PID: $BACKEND_PID)"

sleep 2

# Start Frontend  
echo "⚛️  Starting Frontend on port 5173..."
npm install &> /dev/null
npm run dev &
FRONTEND_PID=$!
echo "✅ Frontend started (PID: $FRONTEND_PID)"

echo ""
echo "================================================"
echo "🧠 MindLoop is running!"
echo "================================================"
echo ""
echo "📱 Frontend:  http://localhost:5173"
echo "🔌 Backend:   http://localhost:3001"
echo "📚 API Docs:  http://localhost:3001/api"
echo ""
echo "Press Ctrl+C to stop all services"
echo ""

# Keep script running
wait
