// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Filter courses by level
function filterCourses(level) {
    const courses = document.querySelectorAll('.course-item');
    const buttons = document.querySelectorAll('.filter-btn');
    
    // Update active button
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Filter courses
    courses.forEach(course => {
        if (level === 'all') {
            course.style.display = 'block';
        } else if (course.classList.contains(level)) {
            course.style.display = 'block';
        } else {
            course.style.display = 'none';
        }
    });
}

// Contact form handling
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        // Show success message
        const formMessage = document.getElementById('formMessage');
        formMessage.textContent = 'Thank you for your message! We\'ll get back to you soon.';
        formMessage.style.color = '#28a745';
        formMessage.style.display = 'block';
        
        // Reset form
        this.reset();
        
        // Clear message after 5 seconds
        setTimeout(() => {
            formMessage.style.display = 'none';
        }, 5000);
        
        console.log('Form submitted:', data);
    });
}

// Add scroll effect to navbar
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.15)';
    } else {
        navbar.style.boxShadow = 'var(--shadow)';
    }
});

// Animate elements on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe course cards and other elements
document.querySelectorAll('.course-card, .tutorial-card, .feature, .resource-item').forEach(el => {
    observer.observe(el);
});

// Mobile menu toggle (for future mobile menu implementation)
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    navMenu.classList.toggle('active');
}

// Add keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Press 'H' to go home
    if (e.key.toLowerCase() === 'h') {
        window.location.href = 'index.html';
    }
    // Press 'C' to go to courses
    if (e.key.toLowerCase() === 'c') {
        window.location.href = 'courses.html';
    }
});

// Page load animation
window.addEventListener('load', function() {
    document.body.style.opacity = '1';
});

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth page transitions
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.opacity = '1';
        document.body.style.transition = 'opacity 0.3s ease';
    }, 100);
});
